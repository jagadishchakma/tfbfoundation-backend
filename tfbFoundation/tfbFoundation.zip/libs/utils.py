backend_live_link = 'http://127.0.0.1:8000'
frontend_live_link = 'http://localhost:5173'